#include <rosconsole_bridge/bridge.h>
REGISTER_ROSCONSOLE_BRIDGE;
